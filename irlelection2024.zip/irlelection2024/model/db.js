var mysql = require('mysql');

var connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'irlelection2024',
  multipleStatements: true
});

connection.connect(function (err) {
  if (err) throw err;
  console.log(`Successfully connected to MySQL database irlelection2024...`);
});

exports.getSummary = function (req, res) {

  connection.query("SELECT n.PARTY_MNEMONIC, n.FIRST_PREFERENCE_VOTES_2024, n.SHARE_OF_THE_VOTE_2024, n.SEATS_WON_2024, p.PARTYNAME, p.PARTYCOLOUR FROM nationalsummary n JOIN parties p WHERE n.PARTY_MNEMONIC = p.PARTY_MNEMONIC ORDER BY n.SEATS_WON_2024 DESC;", function (err, rows, fields) {
    if (err) throw err;
    res.send(JSON.stringify(rows));
  });

}

exports.getParties = function (req, res) {

  connection.query("SELECT * FROM parties ORDER BY PARTY_MNEMONIC", function (err, rows, fields) {
    if (err) throw err;
    res.send(JSON.stringify(rows));
  });

}

exports.getCandidates = function (req, res) {

  connection.query("SELECT can.CANDIDATE_ID, can.CONSTITUENCY, con.NAME, can.FIRSTNAME, can.SURNAME, can.GENDER, can.PARTY_MNEMONIC, can.CURRENT_STATUS FROM candidates can JOIN parties p, constituencies con WHERE can.PARTY_MNEMONIC = p.PARTY_MNEMONIC AND can.CONSTITUENCY = con.CONSTITUENCY ORDER BY can.SURNAME, can.FIRSTNAME ", function (err, rows, fields) {
    if (err) throw err;
    res.send(JSON.stringify(rows));
  });

}

exports.getConstituencies = function (req, res) {

  connection.query("SELECT * FROM constituencies ORDER BY NAME", function (err, rows, fields) {
    if (err) throw err;
    res.send(JSON.stringify(rows));
  });

}


exports.getConstituencyPartyResult = function (req, res) {
  constituency = req.params.constituency;
  connection.query(`SELECT p.PARTY_MNEMONIC, p.PARTYCOLOUR, SUM(c.NOVOTES) AS PARTY_VOTES, con.NAME, con.CONSTITUENCY FROM constituencies con JOIN counts c ON con.CONSTITUENCY = c.CONSTITUENCY JOIN candidates can ON con.CONSTITUENCY = can.CONSTITUENCY AND can.CANDIDATE_ID = c.CANDIDATE_ID JOIN parties p ON can.PARTY_MNEMONIC = p.PARTY_MNEMONIC WHERE con.NAME = '${constituency}' AND c.COUNTNUMBER = 1 GROUP BY p.PARTY_MNEMONIC, p.PARTYCOLOUR;`, function (err, rows, fields) {
    if (err) throw err;
    res.send(JSON.stringify(rows));
  });

}

exports.getConstituencyCandidateResult = function (req, res) {

  constituency = req.params.constituency;

  connection.query(`SELECT can.FIRSTNAME, can.SURNAME, SUM(c.NOVOTES) AS VOTES, p.PARTY_MNEMONIC, p.PARTYCOLOUR FROM candidates can JOIN counts c ON can.CANDIDATE_ID = c.CANDIDATE_ID JOIN constituencies con ON can.CONSTITUENCY = con.CONSTITUENCY JOIN parties p ON can.PARTY_MNEMONIC = p.PARTY_MNEMONIC WHERE con.NAME = '${constituency}' AND c.COUNTNUMBER = 1 GROUP BY can.CANDIDATE_ID;`, function (err, rows, fields) {
    if (err) throw err;
    res.send(JSON.stringify(rows));
  });

}

exports.getConstituencyCandidate = function (req, res) {

  connection.query("", function (err, rows, fields) {
    if (err) throw err;
    res.send(JSON.stringify(rows));
  });

}


exports.getCandidatesbyParty = function (req, res) {
  party = req.params.party;

  connection.query(`SELECT * FROM candidates WHERE Party_MNEMONIC = "${party}"`, function (err, rows, fields) {
    if (err) throw err;
    res.send(JSON.stringify(rows));
  });

}

exports.getCandidatesbyConstituency = function (req, res) {
  constituency = req.params.constituency;

  connection.query(`SELECT * FROM candidates WHERE constituency = "${constituency}"`, function (err, rows, fields) {
    if (err) throw err;
    res.send(JSON.stringify(rows));
  });

}

exports.checkLogin = function (req, res) {
  var email = req.params.email;
  var password = req.params.password;
  connection.query(`SELECT * FROM admin WHERE email = "${email}" AND password = "${password}"`, function (err, rows, fields) {
    if (err) throw err;

    if (rows.length == null) {
      res.send("Invalid Credentials");
    }

    else {
      res.send(JSON.stringify(rows));
    }

  });

}


exports.UpdateResults = function (req, res) {

  var partyName = req.body.partyName;
  var partyMnemonic = req.body.partyMnemonic;

  connection.query(`UPDATE parties SET PARTYNAME = '${partyName}' WHERE PARTY_MNEMONIC = '${partyMnemonic}' `, function (err, rows, fields) {
    if (err) throw err;

    res.send(JSON.stringify(rows));

  });

}