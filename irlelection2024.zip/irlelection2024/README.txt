

$ npm install

$ node index.js


