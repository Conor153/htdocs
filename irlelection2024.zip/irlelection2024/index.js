var express = require("express");
var bodyParser = require("body-parser");
var cors = require("cors");
var db = require("./model/db.js");

var app = express();

app.use(cors());
app.use(express.static('public'));  //

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));


app.get("/summary", function (req, res) {
  db.getSummary(req, res);
});

app.get("/parties", function (req, res) {
  db.getParties(req, res);
});

app.get("/candidates", function (req, res) {
  db.getCandidates(req, res);
});

app.get("/constituencies", function (req, res) {
  db.getConstituencies(req, res);
});

app.get("/constituency/:constituency?", function (req, res) {
  db.getConstituencyPartyResult(req, res);
});

app.get("/constituency/candidates/:constituency?", function (req, res) {
  db.getConstituencyCandidateResult(req, res);
});

app.get("/candidatesPartyConstituency", function (req, res) {
  db.getConstituencyParty(req, res);
});

app.get("/candidatesPartyConstituency", function (req, res) {
  db.getConstituencyCandidate(req, res);
});

app.get("/candidates/party/:party?", function (req, res) {
  db.getCandidatesbyParty(req, res);
});

app.get("/candidates/constituency/:constituency?", function (req, res) {
  db.getCandidatesbyConstituency(req, res);
});

app.post("/login/:email?/:password?", function (req, res) {
  db.checkLogin(req, res);
});

app.post("/updateResults", function (req, res) {
  db.UpdateResults(req, res);
});


var myServer = app.listen(3000, function () {
  console.log("IRLElection2024 Server listening on port 3000...");
});
