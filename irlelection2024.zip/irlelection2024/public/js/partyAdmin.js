$(`document`).ready(function () {
    nav();
    footer();
    getJsonData();
});
function getJsonData() {
    $.getJSON(`http://localhost:3000/parties`, function (data) {
        _.each(data, function (element) {
            $(`#tbody`).append(
                `<tr>
                <td>${element.PARTY_MNEMONIC}</td>
                <td><input class="form-control" id="Candidate1${element.PARTY_MNEMONIC}" type="text" value="${element.PARTYNAME}"></td>
                <td><button type="button" class="updateButton btn btn-primary" value="${element.PARTY_MNEMONIC}">Update</button></td>
                </tr>`
            );
        });
        $(".updateButton").click(function (e) {
            let partyMnemonic = e.target.value;
            let partyName = $(`#Candidate1${partyMnemonic}`).val();
            $.post(`http://localhost:3000/updateResults`, {
                partyMnemonic: partyMnemonic,
                partyName: partyName,
            });
        });
    });
}