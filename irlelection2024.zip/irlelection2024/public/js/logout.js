$(`document`).ready(function () {
    sessionStorage.setItem("login", "false");
    location.replace("index.html");
});