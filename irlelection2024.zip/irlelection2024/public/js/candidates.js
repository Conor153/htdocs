$(`document`).ready(function () {
    nav();
    footer();
    getJsonData()
    PartyDD()
    ConstituencyDD()
});
function getJsonData() {
    barHeight = 50;
    barWidth = 50;
    spacing = 10;

    $.getJSON(`http://localhost:3000/candidates`, function (data) {
        AppendTable(data)
        $(`#party`).change(function () {
            $(`#tbody`).empty();
            if ($(`#party`).val() == 0) {
                AppendTable(data)
            }
            else {
                var filteredData = _.filter(data, getParty);
                function getParty(element) {
                    if (element.PARTY_MNEMONIC == $(`#party`).val())
                        return true;
                }
                AppendTable(filteredData)
            }
        });
        $(`#constituency`).change(function () {
            $(`#tbody`).empty();
            if ($(`#constituency`).val() == 0) {
                AppendTable(data)
            }
            else {
                var filteredData = _.filter(data, getConstituency);
                function getConstituency(element) {
                    if (element.CONSTITUENCY == $(`#constituency`).val())
                        return true;
                }
                AppendTable(filteredData)
            }
        });
    });
}

function PartyDD() {
    $.getJSON(`http://localhost:3000/parties`, function (data) {
        _.each(data, function (element, i) {
            $(`#party`).append(`<option value=${element.PARTY_MNEMONIC}>${element.PARTYNAME}</option>`)
        });
    });
}

function ConstituencyDD() {
    $.getJSON(`http://localhost:3000/constituencies`, function (data) {
        _.each(data, function (element, i) {
            $(`#constituency`).append(`<option value=${element.CONSTITUENCY}>${element.NAME}</option>`)
        });
    });
}


function AppendTable(data) {
    _.each(data, function (element, i) {
        $(`#tbody`).append(
            `<tr>
            <td>${i + 1}</td>
            <td>${element.SURNAME} ${element.FIRSTNAME}</td>
            <td>${element.PARTY_MNEMONIC}</td>
            <td>${element.NAME}</td>
            </tr>`
        );
    });
}