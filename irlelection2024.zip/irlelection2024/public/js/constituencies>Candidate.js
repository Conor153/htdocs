$(`document`).ready(function () {
    nav();
    footer();
    getJsonData();
  });
  function getJsonData() {
    $.getJSON(`http://localhost:3000/constituencies`, function (data) {
      function sortByName(element) {
        return element.NAME;
      }
      var data = _.sortBy(data, sortByName);
      _.each(data, function (element) {
        $(`#tbody`).append(
          `<tr>
                      <td><a class="constituency nav-item" value="${element.CONSTITUENCY}" href=constituencyDetails.html>${element.NAME}</a></td>
                      <td>${element.NOSEATS}</td>
                      <td>${element.NOCANDIDATES}</td>
                      <td>${element.ELECTORATE.toLocaleString()}</td>
                      <td>${element.QUOTA.toLocaleString()}</td>
                      <td>${element.PERCENTTURNOUT}%</td>
                      </tr>`
        );
      });
      $(`.constituency`).click(function () {
        sessionStorage.removeItem('data');
        sessionStorage.setItem("constituency", `${$(this).text()}`);
        sessionStorage.setItem("data", `candidates`);
      });
    });
  } 