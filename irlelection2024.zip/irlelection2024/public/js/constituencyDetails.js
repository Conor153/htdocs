$(`document`).ready(function () {
  nav();
  footer();
  var constituency = sessionStorage.getItem("constituency")
  $(`#constituency`).append(
    `${constituency}`
  );
  if (sessionStorage.getItem("data") == "candidates") {
    getCandidateData(constituency)
  }
  else {
    getJsonData(constituency);
  }
});

function getJsonData(constituency) {
  $.getJSON(`http://localhost:3000/constituency/${constituency}`, function (data) {
    var voteCount = _.pluck(data, "PARTY_VOTES");
    var height = 250;
    var width = _.size(data) * 60;
    var barWidth = 50;
    var spacing = 10;
    var totalVote = 0;
    _.each(voteCount, function (element) {
      totalVote += element
    });

    function sortByVote(element) {
      return -element.PARTY_VOTES;
    }
    var data = _.sortBy(data, sortByVote);

    var svg = d3
      .select("#bars")
      .append("svg")
      .attr("width", width)
      .attr("height", height);
    var svg2 = d3
      .select("#squares")
      .append("svg")
      .attr("width", width)
      .attr("height", 100);

    var barChart = svg.append("g");
    var text = svg.append("g");
    var squares = svg2.append("g");
    var text2 = svg2.append("g");

    var h = d3.scaleLinear()
      .domain([0, 100])
      .range([0, height]);
    $(`#thead`).append(
      `<tr>
          <th>Party</th>
          <th>Votes</th>
          <th>%</th>
          </tr>`
    );
    $(`#data`).append(
      `<a href="constituencies>Party.html" class="btn btn-primary">Back</a>
      <br>
      <h2>% of 1st Preference Votes</h2>`
    );

    _.each(data, function (element, i) {
      $(`#tbody`).append(
        `<tr>
                    <td>${element.PARTY_MNEMONIC}</td>
                    <td>${element.PARTY_VOTES.toLocaleString()}</td>
                    <td>${((element.PARTY_VOTES / totalVote) * 100).toFixed(1)}%</td>
                    </tr>`
      );

      barChart.append("rect")
        .attr('x', (barWidth + spacing) * i)
        .attr('y', 0)
        .attr('width', barWidth)
        .attr('height', height)
        .attr('fill', `#f2f0ef`);

      barChart.append("rect")
        .attr('x', (barWidth + spacing) * i)
        .attr('y', height - h((element.PARTY_VOTES / totalVote) * 100).toFixed(1))
        .attr('width', barWidth)
        .attr('height', h((element.PARTY_VOTES / totalVote) * 100).toFixed(1))
        .attr('fill', `${element.PARTYCOLOUR}`);

      text.append("text")
        .text(`${((element.PARTY_VOTES / totalVote) * 100).toFixed(1)}`)
        .attr("x", ((barWidth + spacing) * i) + barWidth / 2)
        .attr("y", height - h((element.PARTY_VOTES / totalVote) * 100).toFixed(1) - spacing)
        .attr("text-anchor", "middle")
        .attr("font-weight", "bold")
        .attr("font-size", 15)
        .attr("fill", "black");

      squares.append("rect")
        .attr("x", ((barWidth + spacing) * i) + barWidth / 4)
        .attr('y', 0)
        .attr('width', 25)
        .attr('height', 25)
        .attr('fill', `${element.PARTYCOLOUR}`);

      text2.append("text")
        .text(`${element.PARTY_MNEMONIC}`)
        .attr("x", ((barWidth + spacing) * i) + barWidth / 2)
        .attr("y", barWidth)
        .attr("text-anchor", "middle")
        .attr("font-size", 15)
        .attr("fill", "black");
    });
  });
}

function getCandidateData(constituency) {
  $.getJSON(`http://localhost:3000/constituency/candidates/${constituency}`, function (data) {

    function sortByVote(element) {
      return -element.VOTES;
    }
    var data = _.sortBy(data, sortByVote);
    var height = _.size(data) * 60;
    var width = 1200;
    var barHeight = 30;
    var spacing = 20;

    var svg = d3
      .select("#bars")
      .append("svg")
      .attr("width", width)
      .attr("height", height);

    var barChart = svg.append("g");
    var text = svg.append("g");

    var maxVote = _.first(data)
    var w = d3.scaleLinear()
      .domain([0, maxVote.VOTES])
      .range([0, width - 200]);
    $(`#thead`).append(
      `<tr>
        <th>Party</th>
        <th>Name</th>
        <th>Votes</th>
        </tr>`
    );
    $(`#data`).append(
      `<a href="constituencies>Candidate.html" class="btn btn-primary">Back</a>
      <br>
      <h2>1st Preference Votes</h2>`
    );
    _.each(data, function (element, i) {
      $(`#tbody`).append(
        `<tr>
          <td>${element.PARTY_MNEMONIC}</td>
          <td>${element.SURNAME}, ${element.FIRSTNAME}</td>
          <td>${element.VOTES.toLocaleString()}</td>
          </tr>`
      );



      barChart.append("rect")
        .attr('x', 0)
        .attr('y', ((barHeight + spacing) * i) + spacing)
        .attr('width', width)
        .attr('height', barHeight)
        .attr('fill', `#f2f0ef`);

      barChart.append("rect")
        .attr('x', 0)
        .attr('y', ((barHeight + spacing) * i) + spacing)
        .attr('width', w(element.VOTES))
        .attr('height', barHeight)
        .attr('fill', `${element.PARTYCOLOUR}`);

      text.append("text")
        .text(`${element.SURNAME}, ${element.FIRSTNAME} (${element.PARTY_MNEMONIC})`)
        .attr("x", 0)
        .attr("y", ((barHeight + spacing) * i) + (barHeight / 2))
        .attr("font-size", 15)
        .attr("fill", "black");

      text.append("text")
        .text(`${element.VOTES.toLocaleString()}`)
        .attr("x", width - 50)
        .attr("y", ((barHeight + spacing) * i) + (spacing + barHeight / 2 + 5))
        .attr("font-size", 16)
        .attr("fill", "black");

    })
  })
}