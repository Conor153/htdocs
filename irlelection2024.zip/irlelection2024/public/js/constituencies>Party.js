$(`document`).ready(function () {
  nav();
  footer();
  getJsonData();
});
function getJsonData() {
  $.getJSON(`http://localhost:3000/constituencies`, function (data) {

    function sortByName(element) {
      return element.NAME;
    }
    var data = _.sortBy(data, sortByName);

    var svg = d3
      .select("#map")
      .append("svg")
      .attr("width", 1000)
      .attr("height", 1000);
    var map = svg.append("g");
    _.each(data, function (element) {
      $(`#tbody`).append(
        `<tr>
                    <td><a class="constituency" value="${element.CONSTITUENCY}" href=constituencyDetails.html>${element.NAME}</a></td>
                    <td>${element.NOSEATS}</td>
                    <td>${element.NOCANDIDATES}</td>
                    <td>${element.ELECTORATE.toLocaleString()}</td>
                    <td>${element.QUOTA.toLocaleString()}</td>
                    <td>${element.PERCENTTURNOUT}%</td>
                    </tr>`
      );
      map.append("path")
        .attr('d', element.PATH)
        .attr('id', `${element.NAME}`)
        .attr('fill', 'grey')
        .attr('transform', 'translate(-1500, 0) scale(3)')
        .attr('text', `${element.NAME}`)
        .on('click', function (e) {
          sessionStorage.removeItem('data');
          sessionStorage.setItem("constituency", d3.select(this).attr('id'));
          sessionStorage.setItem("data", `parties`);
          location.replace("http://localhost:3000/constituencyDetails.html");
        });
    });
    $(`.constituency`).click(function () {
      sessionStorage.removeItem('data');
      sessionStorage.setItem("constituency", `${$(this).text()}`);
      sessionStorage.setItem("data", `parties`);
    });
  });
} 