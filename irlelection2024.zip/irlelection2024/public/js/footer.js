function footer() {
    var footerOutPut = `
    <hr>
    <p> &copy; L00173495 Web Development and Libraries 2025</p>`
    $("#footer").html(footerOutPut);
}