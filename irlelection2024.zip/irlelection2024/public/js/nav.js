function nav() {
    var navOutPut = `
    <a href="summary.html">
        <img src="images/logo2.png" class="d-inline-block align-text-top navbar-brand" style="border-radius: 50px">
    </a>
    <ul class="navbar-nav">
    <li class="nav-item">
    <a href ="index.html" class="nav-link">Routes</a>
    </li>
    <li class="nav-item">
    <a href ="summary.html" class="nav-link">Summary</a>
    </li>
    <li class="nav-item">
    <a href ="parties.html" class="nav-link">Parties</a>
    </li>
    <li class="nav-item">
    <a href ="candidates.html" class="nav-link">Candidates</a>
    </li>
    <li class="nav-item">
    <a href ="constituencies>Party.html" class="nav-link">Constituencies>Party</a>
    </li>
        <li class="nav-item">
    <a href ="constituencies>Candidate.html" class="nav-link">Constituencies>Candidate</a>
    </li>
    `;
    if (sessionStorage.getItem("login") == "true") {
        navOutPut += `
        <li class="nav-item">
        <a href ="partyAdmin.html" class="nav-link">Party Admin</a>
        </li> |
        <li class="nav-item">
        <a href ="logout.html" class="nav-link">Logout</a>
        </li> |`;
    }

    else {
        navOutPut += `<li class="nav-item">
    <a href ="login.html" class="nav-link">Login</a>
    </li>`;
    }
    navOutPut += `</ul>`;
    $("nav").html(navOutPut);
}

