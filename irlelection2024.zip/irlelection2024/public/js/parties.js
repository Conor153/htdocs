$(`document`).ready(function () {
  nav();
  footer();
  getJsonData();
});
function getJsonData() {
  $.getJSON(`http://localhost:3000/parties`, function (data) {
    _.each(data, function (element) {
      $(`#tbody`).append(
        `<tr>
                <td>${element.PARTY_MNEMONIC}</td>
                <td>${element.PARTYNAME}</td>
                </tr>`
      );
    });
  });
}
