$(`document`).ready(function () {
    nav();
    footer();
    getJsonData()
});
function getJsonData() {
    height = 150;
    width = 1500;
    barHeight = 100;
    barWidth = 100;
    spacing = 10;
    $.getJSON(`http://localhost:3000/summary`, function (data) {

        var svg = d3
            .select("#svg")
            .append("svg")
            .attr("width", width)
            .attr("height", height);
        var squares = svg.append("g");

        data.sort(function (a, b) {
            if (a.SEATS_WON_2024 > b.SEATS_WON_2024)
                return -1;
            else if (a.SEATS_WON_2024 < b.SEATS_WON_2024)
                return 1;
            else (a.SEATS_WON_2024 == b.SEATS_WON_2024)
            {
                if (a.FIRST_PREFERENCE_VOTES_2024 > b.FIRST_PREFERENCE_VOTES_2024)
                    return -1;
                else
                    return 1;
            }
        });

        _.each(data, function (element, i) {

            var text = svg.append("g");
            squares.append("rect")
                .attr('x', (barWidth + spacing) * i)
                .attr('y', 0)
                .attr('width', barWidth)
                .attr('height', barHeight)
                .attr('fill', `${element.PARTYCOLOUR}`);

            text.append("text")
                .attr("y", 20)
                .attr("x", ((barWidth + spacing) * i) + barWidth / 2)
                .attr("text-anchor", "middle")
                .text(`${element.PARTY_MNEMONIC}`)
                .attr("font-size", 18)
                .attr("fill", "white");

            text.append("text")
                .attr("y", 60)
                .attr("x", ((barWidth + spacing) * i) + barWidth / 2)
                .attr("text-anchor", "middle")
                .text(`${element.SEATS_WON_2024}`)
                .attr("font-size", 30)
                .attr("fill", "white");

            text.append("text")
                .attr("y", 90)
                .attr("x", ((barWidth + spacing) * i) + barWidth / 2)
                .attr("text-anchor", "middle")
                .text(`SEATS`)
                .attr("font-size", 18)
                .attr("fill", "white");

            $(`#tbody`).append(
                `<tr>
                <td>${element.PARTY_MNEMONIC}</td>
                <td>${element.FIRST_PREFERENCE_VOTES_2024.toLocaleString()}</td>
                <td>${element.SEATS_WON_2024}</td>
                </tr>`
            );
        });
    });
} 