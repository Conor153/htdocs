$(`document`).ready(function () {
    sessionStorage.setItem("login", "false");
    location.replace("http://localhost/a2/login.html");
});