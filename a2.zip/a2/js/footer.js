function footer() {
    var footerOutPut = `
    <p> &copy; L00173495 Client Side Development 2024</p>`
    $("#footer").html(footerOutPut);
}