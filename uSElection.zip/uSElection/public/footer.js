function footer() {
    var footerOutPut = `
    <p> &copy; L00173495 Server Side Development 2024</p>`
    $("#footer").html(footerOutPut);
}